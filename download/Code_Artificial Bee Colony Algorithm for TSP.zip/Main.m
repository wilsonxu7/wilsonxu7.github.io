clear all;
clc;

tic
%% Generate the map
N = 100;                         % num of cities
rng(2019);
Map = randi([0,100],[N,2]);     % randomly generate the coordination of all the cities
d = distance(Map);              % initial distance
fitness = CalculateFitness(d);  % initial fitness    

% plot of initial route
figure(1)
plot([Map(:,1);Map(1,1)],[Map(:,2);Map(1,2)],'-ob','Linewidth',1.5);
pbaspect([1 1 1]);
axis([0 100 0 100]);
grid on;
title(['(ABC)Initial route with distance:',num2str(d)]);
hold off;


%% Initialization of ABC
D = N;                          % Dimension of the problem
NP = 20;                        % Colony size(Emloyed bees+onlooker bees)
FoodSourceNum = NP/2;           % Number of food sources
trial = zeros(FoodSourceNum,1); % Used to count failure times of improvement 
kmax = 5000;                    % Maimum iteration time
limit = 50;                     % If a food source couldn't improve for limit time, abandon it
BestSols = zeros(kmax+1,1);       % To store the best solution(distance value) in each iteration
BestFitness = zeros(kmax+1,1);    % To store the best fitness in each iteration
BestFoodSource = zeros(kmax+1,D); % To store the best food source in each iteration


% Generate initial food source randomly and evaluate fitness
Foods = zeros(FoodSourceNum,D);   % A FoodSourceNum by D matrix,each row is a randperm of D
FunVal = zeros(FoodSourceNum,1);    % To store distances
for itr=1:FoodSourceNum
    Foods(itr,:) = randperm(D);
    tempMap = Map(Foods(itr,:),:);
    FunVal(itr) = distance(tempMap);
end
Fitness = CalculateFitness(FunVal); % Calculate fitness

% Get the best solution of initial food source
BestInd = find(FunVal == min(FunVal));          % This be a vector(multiple euqal smallest value)
BestInd = BestInd(1);                           % Choose one is okay
MinVal = FunVal(BestInd);                       % Min function
MinPara = Foods(BestInd,:);                     % Where attains the min function value

% Store
BestSols(1) = MinVal;
BestFitness(1) = Fitness(BestInd);
BestFoodSource(1,:) = MinPara;
GlobalBestPara = MinPara;
GlobalSol = MinVal;
GlobalFitness = Fitness(BestInd);

%% Main of ABC
k=0;
while(k<kmax)
    
    %% Employed Bee Phase
    for i=1:FoodSourceNum
        tempFood = mutationOperation(i,Foods);
        
        % Greedy selection
        tempFunVal = distance(Map(tempFood,:));
        tempFitness = CalculateFitness(tempFunVal);
        if (tempFitness>Fitness(i))
            Foods(i,:) = tempFood;
            Fitness(i) = tempFitness;
            FunVal(i) = tempFunVal;
            trial(i) = 0;                           % get improved, reset trial                
        else
            trial(i) = trial(i)+1;                  % no improvement
        end                 
    end
    
    %% Calculate Probabilities
     % P_i = 0.9*fit_i/f_{best}+0.1: 
     % reference: <A Combinatorial Artificial Bee Colony Algorithm for 
     %               Traveling Salesman Problem>
     prob = (0.9.*Fitness./max(Fitness))+0.1;    
    
     
    %% Onlooker Bee Phase
    for t=1:FoodSourceNum
        if(rand<prob(t))
            tempFood = mutationOperation(t,Foods);

            % Greedy selection
            tempFunVal = distance(Map(tempFood,:));
            tempFitness = CalculateFitness(tempFunVal);
            if (tempFitness>Fitness(t))
                Foods(t,:) = tempFood;
                Fitness(t) = tempFitness;
                FunVal(t) = tempFunVal;
                trial(t) = 0;                           % get improved, reset trial                
            else
                trial(t) = trial(t)+1;                  % no improvement
            end               
        end
    end   
    
    %% Scout Bee Phase
     % determine the food sources whose trial counter exceeds the "limit" value
     % here only one scout, need to be modified!!!!
     ind = find(trial>=limit);
     for itr=1:length(ind)
         tempInd = ind(itr);
         midDistance = median(FunVal);
         if FunVal(tempInd)<midDistance
             trial(tempInd)=0;
             toAbandon = Foods(tempInd,:);
             newFood = findNewSource(toAbandon,Map);
             newFunVal = distance(Map(newFood,:));
             newFitness = CalculateFitness(newFunVal);
             Foods(tempInd,:) = newFood;
             FunVal(tempInd) = newFunVal;
             Fitness(tempInd) = newFitness;         
         else
             trial(tempInd)=0;  
             newFood = randperm(D);
             newFunVal = distance(Map(newFood,:));
             newFitness = CalculateFitness(newFunVal);
             Foods(tempInd,:) = newFood;
             FunVal(tempInd) = newFunVal;
             Fitness(tempInd) = newFitness;
         end
     end
     
    %% store best food source at each iteration
    ind = find(FunVal == min(FunVal));
    ind = ind(1);
    tempBestFood = Foods(ind,:);
    tempBestFitness = Fitness(ind);
    tempBestFunVal = FunVal(ind);
    
    BestSols(k+2) = tempBestFunVal;
    BestFitness(k+2) = tempBestFitness;
    BestFoodSource(k+2,:) = tempBestFood;
    
    if GlobalSol>tempBestFunVal
        GlobalBestPara = tempBestFood;
        GlobalSol = tempBestFunVal;
        GlobalFitness = tempBestFitness;
    end
    
    fprintf('itr:%d \t\t, min:%.8f \n',k,GlobalSol);
    
    %%  increment k
    k = k+1;
end

figure(2)
Final = Map(GlobalBestPara,:);
plot([Final(:,1);Final(1,1)],[Final(:,2);Final(1,2)],'-ob','Linewidth',1.5);
pbaspect([1 1 1]);
axis([0 100 0 100]);
grid on;
t = toc;
title({['(ABC)Final route with distance:',num2str(GlobalSol)],['Elapsed time:',num2str(t)],['City size:',num2str(N)]});
hold off;


%% Plot best solutions over each iteration
figure(3)
plot(BestSols,'LineWidth',1.5);
axis([0,kmax,min(BestSols),max(BestSols)]);
title('Minimum distance at each iteration');
xlabel('itetartion time:k');
ylabel('Min(d)');
grid on;
pbaspect([2501 max(BestSols)-min(BestSols) 1]);

