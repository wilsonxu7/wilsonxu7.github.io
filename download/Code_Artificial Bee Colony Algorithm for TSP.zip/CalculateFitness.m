function [Fitness] = CalculateFitness(FunVal)

    Num = length(FunVal);
    Fitness = zeros(Num,1);
    
    % Calculate fitness from function value
    ind = find(FunVal>=0);
    Fitness(ind) = 1./(1+FunVal(ind));
    ind = find(FunVal<0);
    Fitness(ind) = 1+abs(FunVal(ind));
end