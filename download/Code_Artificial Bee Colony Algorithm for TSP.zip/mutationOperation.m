function [mutated] = mutationOperation(ind,Foods)

    [FoodSourceNum,D] = size(Foods);
    toMutate = Foods(ind,:);
    
    % swap mutation
    randIndex = randperm(D);
    temp1 = randIndex(1);
    temp2 = randIndex(2);
    for itr=1:D
        if toMutate(itr)==temp1
            toMutate(itr)=temp2;
        elseif toMutate(itr)==temp2
            toMutate(itr)=temp1;
        end
    end   
    
    mutated = toMutate;
end