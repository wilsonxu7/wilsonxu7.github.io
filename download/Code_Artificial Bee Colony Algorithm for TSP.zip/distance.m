% calculate the fitness
% A: N by 2 matrix, N is num of cities, each row of A stores the position

function [d] = distance(A) 
    d = 0;
    N = length(A);      % num of cities
    for i=1: (N-1)
        difference = A(i,:)-A(i+1,:);
        d = sqrt( sum( difference.^2) )+d; 
    end
    
    d = d + sqrt( sum( (A(1,:)-A(N,:)).^2) );
    f = 1.0/(1+d);             
end