function [newSource] = findNewSource(toAbandon,Map)

    D = length(toAbandon);      % dimension
    R1 = randi([1,D]);      % randomly generated position R1 in the tour
    R2 = randi([1,D]);      % randomly generated position R2 in the tour 
    Lmax = floor(D/3);
    Prc = 1;
    Pl = 0.05;

    
    while(R1==R2)                       % to keep R1 \neq R2
        R2 = randi([1,D]);
    end

    % keep R1<R2
    if R1>R2
        temp = R1;
        R1 = R2;
        R2 = temp;
        clear temp;
    end

    % keep length < Lmax
    if R2>(R1+Lmax)
        R2 = R1+Lmax; 
    end

    % keep R2 \leq D
    if R2>D
        R2 = D;
    end

    % extrat sub-tour [R1-R2]
    subtour = toAbandon(R1:R2);
    remaining = toAbandon([1:(R1-1) (R2+1):end]);
    lenSub = length(subtour);
    lenRemaining = length(remaining); 
    
    
    % mutation
    if rand()<Prc 
        % minimum extension
        minDistance = Inf;
        bestPerm = 0;

        for itr=1:lenRemaining
            tempPerm = [remaining(1:itr-1), subtour, remaining(itr:lenRemaining)];
            tempMap = Map(tempPerm,:);
            tempDistance = distance(tempMap);

            if tempDistance<minDistance
                minDistance = tempDistance;
                bestPerm = tempPerm;
            end            
        end

        newSource = bestPerm;
    else
         w = R1;
         while(lenSub>0)
             if rand()<Pl
                 k = randi([1,lenSub]);
                 remaining = [remaining(1:w-1),subtour(k),remaining(w:end)];
                 subtour = [subtour(1:k-1),subtour(k+1:end)];
                 lenSub=length(subtour);                
             else
                 k = lenSub;
                 remaining = [remaining(1:w-1),subtour(k),remaining(w:end)];
                 subtour = [subtour(1:k-1),subtour(k+1:end)];
                 lenSub=length(subtour);                   
             end
             w = w+1;
         end
         newSource = remaining;
    end
end